AgentTrace 证据包（Evidence Bundle）
=====================================

本包由 AgentTrace v0.9.0 于 2026-08-31 16:50:50 打包。

包内容
------
  evidence.db             证据库（SQLite；SHA-256 哈希链 + 全部 Agent 事件）
  evidence.db.anchor.json 外部锚定签名（对链尾四元组的签名承诺）
  anchor.public_key.txt   Ed25519 公钥（若有——验证时用它绑定）
  report.html             时间线回放审计报告
  manifest.json           包清单（每个文件的 SHA-256）

验证步骤（验证者需要：AgentTrace + 本包；不需要签名私钥）
--------------------------------------------------------
1. 校验包清单（任何文件被替换都会在此暴露）:
     python -m agenttrace bundle verify-manifest <解包目录>

2. 校验证据链 + 外部锚定:
     python -m agenttrace verify --db <解包目录>/evidence.db
     # Ed25519 锚定请加绑定期望公钥（对抗/合规场景必须）:
     python -m agenttrace seal verify --db <解包目录>/evidence.db \
         --public-key <从可信渠道获得的公钥，应与 anchor.public_key.txt 一致>

3. 打开 report.html 查看时间线回放与风险发现。

安全须知
--------
- 本包验证的是"包内数据自洽 + 与锚定一致"。
- 公钥的信任来自分发渠道（band 之外），请通过独立渠道核对 anchor.public_key.txt。
- 若 anchor 缺失或密钥/公钥不匹配，证据链完整性无法证明，请勿采信。
